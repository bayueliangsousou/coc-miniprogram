const tcb = require('@cloudbase/node-sdk');

const app = tcb.init({
  env: 'cloud1-1gp39wlmaa1fc8d5'
});

const db = app.database();
const _ = db.command;

exports.main = async (event, context) => {
  const { roomCode, characterData, OPENID } = event;

  try {
    // 查找房间
    const roomRes = await db.collection('rooms')
      .where({
        roomCode: roomCode.toUpperCase(),
        status: 'active'
      })
      .limit(1)
      .get();

    if (!roomRes.data || roomRes.data.length === 0) {
      return {
        code: -1,
        message: '房间不存在或已关闭'
      };
    }

    const room = roomRes.data[0];

    // 检查房间是否已满
    if (room.playerCount >= room.maxPlayers) {
      return {
        code: -2,
        message: '房间已满'
      };
    }

    // 检查玩家是否已在房间中
    const existingPlayer = await db.collection('room_players')
      .where({
        roomId: room._id,
        characterId: characterData.id
      })
      .count();

    if (existingPlayer.total > 0) {
      // 玩家已在房间中，更新信息
      await db.collection('room_players')
        .where({
          roomId: room._id,
          characterId: characterData.id
        })
        .update({
          updatedAt: new Date()
        });

      return {
        code: 0,
        message: '已在房间中',
        data: {
          success: true,
          isRejoin: true,
          roomId: room._id,
          campaignId: room.campaignId,
          campaignName: room.campaignName,
          roomCode: room.roomCode
        }
      };
    }

    // 添加玩家到房间
    const now = new Date();
    await db.collection('room_players').add({
      data: {
        roomId: room._id,
        roomCode: room.roomCode,
        characterId: characterData.id,
        characterName: characterData.name,
        occupation: characterData.occupation || '',
        openId: OPENID || '',
        joinedAt: now,
        updatedAt: now
      }
    });

    // 更新房间玩家数量
    await db.collection('rooms').doc(room._id).update({
      playerCount: _.inc(1),
      updatedAt: now
    });

    return {
      code: 0,
      message: '加入成功',
      data: {
        success: true,
        isRejoin: false,
        roomId: room._id,
        campaignId: room.campaignId,
        campaignName: room.campaignName,
        roomCode: room.roomCode
      }
    };
  } catch (error) {
    return {
      code: -99,
      message: '加入房间失败: ' + error.message
    };
  }
};
